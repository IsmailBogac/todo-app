# React İle TodoList
- Todo ekleme
- Silme
- Güncelleme
- Tamamlananları işaretleme
- Todo sayısı
![app](todosProje.gif)
