import './App.css';
import Entry from './components/Entry';

function App() {

  return (
    <div className="App">
      <h1>todos</h1>
      <Entry/>
      <small>Gökhan Güney</small>
    </div>
  );
}

export default App;
